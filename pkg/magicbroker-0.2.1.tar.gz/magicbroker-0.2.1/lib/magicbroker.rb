module Magicbroker
    autoload :Client, 'client/client' 
end
