module Broker
    autoload :Client, 'client/client' 
end
